# Spark Data Lineage Demo

Project demonstrating how to implement dynamic data lineage using Spark. 
<br>
Used and commented in the blog article :
- English version: <i>[How to hack Spark to do some data lineage](https://blog.octo.com/en/how-to-hack-spark-to-do-some-data-lineage/)</i>
- French version: <i>[Comment hacker Spark pour effectuer du data lineage](https://blog.octo.com/comment-hacker-spark-pour-effectuer-du-data-lineage/)</i>
